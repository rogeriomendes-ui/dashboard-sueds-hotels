const key=location.hash.slice(1),msg=document.querySelector('#progress'),retry=document.querySelector('#retry');
async function executar(){
  retry.hidden=true;
  try{
    await navigator.locks.request('tarifas-sueds-calendario',{ifAvailable:true},async lock=>{
      if(!lock)throw Error('Outra atualização WEB está em andamento.');
      const job=(await chrome.storage.session.get(key))[key];
      if(!job)throw Error('Lote encerrado. Abra o painel RMS para consultar as alterações.');
      document.querySelector('#hotel').textContent=job.items[0].hotel;
      const abas=await chrome.tabs.query({currentWindow:true,url:'https://myhotel2.omnibees.com/*'});
      if(abas.length!==1)throw Error('Abra uma aba da Omnibees nesta janela e selecione o hotel do lote.');
      const tabId=abas[0].id;
      for(;job.index<job.items.length;){
        const pedido={...job.items[job.index],lote:true};
        msg.textContent=job.index+' de '+job.items.length+' conferidas. '+pedido.noite+' · '+pedido.grupo+' · '+pedido.quarto;
        const ler=async(aplicar,anterior)=>{
          const [r]=await chrome.scripting.executeScript({target:{tabId},func:calendario360,args:[pedido,aplicar,anterior]});
          if(!r?.result||r.result.erro)throw Error(r?.result?.erro||'Calendário indisponível.');
          return r.result;
        };
        const igual=a=>a.length===pedido.alvos.length&&a.every((n,i)=>n===pedido.alvos[i]);
        const {atual}=await ler(false,null);
        if(!igual(atual)){
          await ler(true,atual);
          await chrome.tabs.reload(tabId);
          let ready=false;
          for(let i=0;i<100;i++){
            if((await chrome.tabs.get(tabId)).status==='complete'){ready=true;break;}
            await new Promise(done=>setTimeout(done,200));
          }
          if(!ready||!igual((await ler(false,null)).atual))throw Error('Gravação ainda não confirmada na Omnibees.');
        }
        job.index++;
        await chrome.storage.session.set({[key]:job});
      }
      msg.textContent=job.index+' combinações WEB conferidas no Calendário 360.';
      await chrome.storage.session.remove(key);
    });
  }catch(e){msg.textContent+=' '+e.message;retry.hidden=false;}
}
retry.onclick=executar;
executar();
