document.addEventListener('click', async event=>{
  const dialog=document.querySelector('#omnibeesTest[open]');
  if(!event.isTrusted || !dialog || event.target.closest('button')!==dialog.querySelector('#omniNext') || !dialog.dataset.lote)return;
  const msg=dialog.querySelector('#omniHelp');
  try{
    const result=await chrome.runtime.sendMessage({tipo:'abrir-lote',items:JSON.parse(dialog.dataset.lote)});
    msg.textContent=result?.ok?'Acompanhe a atualização WEB na extensão.':result?.error||'Não foi possível abrir a extensão.';
  }catch{msg.textContent='Recarregue o painel após atualizar a extensão.';}
});
