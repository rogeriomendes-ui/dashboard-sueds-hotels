chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  if(message.tipo!=='abrir-lote'||!sender.tab||new URL(sender.url).origin!=='https://portalsueds.com.br')return;
  (async()=>{
    const items=message.items;
    if(!Array.isArray(items)||!items.length||!items.every(i=>i.hotel===items[0].hotel &&
      ['WEB Café','WEB MAP','WEB PC'].includes(i.grupo)&&/^\d{2}\/\d{2}\/\d{4}$/.test(i.noite)&&
      typeof i.quarto==='string'&&i.paxs?.includes(2)&&i.paxs.length===i.alvos.length&&
      i.paxs.every(p=>Number.isSafeInteger(p)&&p>0)&&i.alvos.every(n=>Number.isSafeInteger(n)&&n>0)))throw Error('Lote WEB inválido.');
    const key=crypto.randomUUID();
    await chrome.storage.session.set({[key]:{items,index:0}});
    await chrome.tabs.create({windowId:sender.tab.windowId,url:chrome.runtime.getURL('lote.html#'+key)});
    return {ok:true};
  })().then(respond,e=>respond({error:e.message}));
  return true;
});
