async function calendario360(pedido, aplicar, anterior) {
  try {
    const normal = s => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
    const unico = itens => itens.length === 1 ? itens[0] : null;
    const visivel = e => e.getClientRects().length > 0;
    const lista = seletor => Array.from(document.querySelectorAll(seletor)).filter(visivel);
    const texto = (seletor, nome) => unico(lista(seletor).filter(e => normal(e.textContent) === normal(nome)));
    const esperar = async fn => {
      for (let i=0;i<50;i++) {
        const resultado = fn();
        if (resultado) return resultado;
        await new Promise(resolve => setTimeout(resolve,100));
      }
      throw Error('A grade não ficou disponível. Confira o hotel, a Vista Tarifário e o período no Calendário 360.');
    };
    const hotelOk = () => texto('#context-sh-context .context-sub-information span',pedido.hotel);
    if (!hotelOk()) throw Error('Selecione ' + pedido.hotel + ' na Omnibees.');
    if (!texto('h4','Calendário 360')) {
      if (!texto('span','Calendário 360')) texto('span','Tarifários e Disponibilidade')?.click();
      (await esperar(() => texto('span','Calendário 360'))).click();
      await esperar(() => texto('h4','Calendário 360'));
    }
    const regime = {'WEB Café':'cafe da manha','WEB MAP':'meia pensao','WEB PC':'pensao completa','WEB FAP':'pensao completa'}[pedido.grupo];
    if (!regime) throw Error('Selecione um tarifário WEB no RMS.');
    const alvo = () => unico(lista('ob-excel-table-line.group').filter(row => {
      const nome = normal(row.querySelector('.groupName')?.textContent).replace(/\s*[-–]\s*/g,' ');
      return nome === 'tarifario web ' + regime && /\bBRL\b/.test(row.innerText);
    }));
    const nivel = await esperar(alvo);
    const descendentes = (row, limite) => {
      const itens = [];
      for (let e=row.nextElementSibling;e && !e.matches(limite);e=e.nextElementSibling) itens.push(e);
      return itens;
    };
    const nomeQuarto = normal(pedido.quarto);
    const nomes = {std:['standard','apartamento standard'],luxo:['luxo','apartamento luxo'],suite:['suite','suite master']};
    const acharQuarto = () => unico(descendentes(alvo(),'.group').filter(row =>
      (nomes[nomeQuarto] || [nomeQuarto]).includes(normal(row.querySelector('.rate-room-information span')?.textContent))));
    const expandir = row => row.querySelector('[data-cy="table-table_line-group_expand_collapse_btn"]')?.click();
    if (!acharQuarto() && !nivel.classList.contains('expanded')) expandir(nivel);
    const quarto = await esperar(acharQuarto);
    const linhaPax = pax => unico(descendentes(acharQuarto(),'.group, :has(.rate-room-information [data-cy^="table-table_line-line_name"])').filter(row =>
      normal(row.querySelector('[data-cy="table-table_line-line_description"]')?.textContent) === pax+' pax'));
    if (!linhaPax(2)) expandir(quarto);
    await esperar(()=>linhaPax(2));
    const paxs=pedido.multipax?[1,2,3,4]:[2];
    function celula(pax){
      const datas=lista('excel-header-day [data-cy^="table-header_day_-_"]');
      const data=unico(datas.filter(e=>e.dataset.cy==='table-header_day_-_'+pedido.noite+'-'));
      const inputs=linhaPax(pax)?.querySelectorAll('input[data-cy^="table-table_line-price_line_decimal"]');
      const input=data && inputs?.length===datas.length && inputs[datas.indexOf(data)];
      if(!input || input.disabled || input.readOnly || !hotelOk())throw Error('Confira a noite e as linhas Pax na grade editável.');
      return input;
    }
    function centavos(pax){
      const valor=celula(pax).value;
      if(!/^\d[\d.]*,\d{2}$/.test(valor))throw Error('Valor ilegível na grade.');
      return Number(valor.replaceAll('.','').replace(',',''));
    }
    const atual=paxs.map(centavos);
    if(!aplicar)return {atual};
    if(atual.some((c,i)=>c!==anterior[i]))throw Error('A grade mudou. Confira novamente.');
    const salvar = unico(lista('button[data-cy="save_btn-input"]'));
    const inativo = botao => botao.disabled || botao.classList.contains('disabled') || botao.getAttribute('aria-disabled') === 'true';
    if (!salvar || !inativo(salvar)) throw Error('Confira e encerre as alterações pendentes do calendário antes de atualizar.');
    for(const [i,pax] of paxs.entries()){
      if(atual[i]===pedido.alvos[i])continue;
      const input=celula(pax);
      input.focus();
      input.value=(pedido.alvos[i]/100).toFixed(2).replace('.',',');
      input.dispatchEvent(new Event('input',{bubbles:true}));
      input.dispatchEvent(new Event('change',{bubbles:true}));
      input.blur();
    }
    if(paxs.some((pax,i)=>centavos(pax)!==pedido.alvos[i]))throw Error('Edição incompleta. Cancele as alterações da grade e confira novamente.');
    // O calendário pode substituir o botão ao processar a edição das células.
    for (let tentativa=0; tentativa<50; tentativa++) {
      const atualSalvar=unico(lista('button[data-cy="save_btn-input"]'));
      if (atualSalvar && !inativo(atualSalvar)) {
        if (paxs.some((pax,i)=>centavos(pax)!==pedido.alvos[i])) throw Error('A grade mudou. Confira os valores antes de salvar.');
        atualSalvar.click();
        return {mensagem:'Salvar acionado. Confira a confirmação no Calendário 360.'};
      }
      await new Promise(resolve=>setTimeout(resolve,100));
    }
    if (paxs.some((pax,i)=>centavos(pax)!==pedido.alvos[i])) throw Error('Os valores da grade mudaram durante a conferência.');
    return {mensagem:'A grade exibe os valores do RMS. Confira a gravação no Calendário 360.'};
  } catch (erro) { return {erro:erro.message}; }
}
