async function calendario360(pedido, aplicar, anterior) {
  try {
    const normal = s => (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
    const unico = itens => itens.length === 1 ? itens[0] : null;
    const visivel = e => e.getClientRects().length > 0;
    const lista = seletor => Array.from(document.querySelectorAll(seletor)).filter(visivel);
    const texto = (seletor, nome) => unico(lista(seletor).filter(e => normal(e.textContent) === normal(nome)));
    const esperar = async fn => {
      for (let i=0;i<50;i++) {
        const resultado = fn();
        if (resultado) return resultado;
        await new Promise(resolve => setTimeout(resolve,100));
      }
      throw Error('A grade não ficou disponível. Confira o hotel, a Vista Tarifário e o período no Calendário 360.');
    };
    const hotelOk = () => texto('#context-sh-context .context-sub-information span',pedido.hotel);
    if (!hotelOk()) throw Error('Selecione ' + pedido.hotel + ' na Omnibees.');
    if (!texto('h4','Calendário 360')) {
      if (!texto('span','Calendário 360')) texto('span','Tarifários e Disponibilidade')?.click();
      (await esperar(() => texto('span','Calendário 360'))).click();
      await esperar(() => texto('h4','Calendário 360'));
    }
    const regime = {'WEB Café':'cafe da manha','WEB MAP':'meia pensao','WEB PC':'pensao completa','WEB FAP':'pensao completa'}[pedido.grupo];
    if (!regime) throw Error('Selecione um tarifário WEB no RMS.');
    const alvo = () => unico(lista('ob-excel-table-line.group').filter(row => {
      const nome = normal(row.querySelector('.groupName')?.textContent).replace(/\s*[-–]\s*/g,' ');
      return nome === 'tarifario web ' + regime && /\bBRL\b/.test(row.innerText);
    }));
    const nivel = await esperar(alvo);
    const descendentes = (row, limite) => {
      const itens = [];
      for (let e=row.nextElementSibling;e && !e.matches(limite);e=e.nextElementSibling) itens.push(e);
      return itens;
    };
    const nomeQuarto = normal(pedido.quarto);
    const nomes = {std:['standard','apartamento standard'],luxo:['luxo','apartamento luxo'],suite:['suite','suite master']};
    const acharQuarto = () => unico(descendentes(alvo(),'.group').filter(row =>
      (nomes[nomeQuarto] || [nomeQuarto]).includes(normal(row.querySelector('.rate-room-information span')?.textContent))));
    const expandir = row => row.querySelector('[data-cy="table-table_line-group_expand_collapse_btn"]')?.click();
    if (!acharQuarto() && !nivel.classList.contains('expanded')) expandir(nivel);
    const quarto = await esperar(acharQuarto);
    const dois = () => unico(descendentes(acharQuarto(),'.group, :has(.rate-room-information [data-cy^="table-table_line-line_name"])').filter(row =>
      normal(row.querySelector('[data-cy="table-table_line-line_description"]')?.textContent) === '2 pax'));
    if (!dois()) expandir(quarto);
    const linha = await esperar(dois);
    const datas = lista('excel-header-day [data-cy^="table-header_day_-_"]');
    const data = unico(datas.filter(e => e.dataset.cy === 'table-header_day_-_' + pedido.noite + '-'));
    const inputs = [...linha.querySelectorAll('input[data-cy^="table-table_line-price_line_decimal"]')];
    const input = data && datas.length === inputs.length && inputs[datas.indexOf(data)];
    if (!input || input.disabled || input.readOnly) throw Error('Exiba a noite ' + pedido.noite + ' na grade editável e tente novamente.');
    const atual = input.value;
    if (!/^\d[\d.]*,\d{2}$/.test(atual)) throw Error('Valor atual ilegível na grade.');
    if (!aplicar) return {atual};
    if (!hotelOk() || atual !== anterior) throw Error('A grade mudou. Confira a tarifa novamente.');
    const limpar = s => s.replaceAll('.','');
    if (limpar(atual) === limpar(pedido.valor)) return {mensagem:'A tarifa já está igual ao RMS.'};
    const salvar = unico(lista('button[data-cy="save_btn-input"]'));
    const inativo = botao => botao.disabled || botao.classList.contains('disabled') || botao.getAttribute('aria-disabled') === 'true';
    if (!salvar || !inativo(salvar)) throw Error('Confira e encerre as alterações pendentes do calendário antes de atualizar.');
    input.focus();
    input.value = limpar(pedido.valor);
    input.dispatchEvent(new Event('input',{bubbles:true}));
    input.dispatchEvent(new Event('change',{bubbles:true}));
    input.blur();
    if (limpar(input.value)!==limpar(pedido.valor) || !hotelOk() || !input.isConnected) throw Error('Confira a edição na grade antes de salvar.');
    if (!salvar.isConnected || inativo(salvar)) throw Error('A grade não habilitou Salvar. Confira a célula.');
    salvar.click();
    return {mensagem:'Salvar acionado. Confira a confirmação no Calendário 360.'};
  } catch (erro) { return {erro:erro.message}; }
}
