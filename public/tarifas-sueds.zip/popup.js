const destinos = {
  Omnibees: 'myhotel2.omnibees.com',
  CVC: 'novoportaldofornecedor.cvc.com.br',
  Juniper: 'intranet.azulviagens.com.br'
};
const campo = id => document.getElementById(id);
const status = document.querySelector('[role=status]');
let origem;

function lerPainel() {
  if (location.origin !== 'https://portalsueds.com.br') return null;
  const hotel = document.querySelector('#panelHotel')?.textContent.trim();
  const tabela = document.querySelector('#nights');
  if (!hotel || !tabela?.tHead || !tabela.tBodies.length || !tabela.getBoundingClientRect().width) return null;
  const teste=document.querySelector('#omnibeesTest[open]');
  const data=teste?.querySelector('#omniDate')?.value;
  const dataTeste=data?.split('-').reverse().join('/');
  const itens = [];
  for (const coluna of tabela.tHead.rows[0].cells) {
    const titulo = coluna.querySelector('.simple-group-title');
    if (!titulo || coluna.lastChild.textContent.trim() !== 'Vigente após flutuação') continue;
    for (const linha of tabela.tBodies[0].rows) {
      const noite = linha.cells[0].textContent.trim();
      if(teste && noite!==dataTeste) continue;
      for (const item of linha.cells[coluna.cellIndex].querySelectorAll('.simple-price-list > strong')) {
        const valor = item.textContent.trim();
        const quarto = item.previousElementSibling?.textContent.trim();
        if (quarto && /^(?:\d{1,3}(?:\.\d{3})*|\d+),\d{2}$/.test(valor) && Number(valor.replaceAll('.','').replace(',','.')) > 0) {
          itens.push({grupo:titulo.textContent.trim(), noite, quarto, valor});
        }
      }
    }
  }
  return {hotel,itens,teste:!!teste,stdPax:teste?.dataset.stdPax?JSON.parse(teste.dataset.stdPax):null};
}

function opcoes(id, itens, chave) {
  campo(id).replaceChildren(...Array.from(new Set(itens.map(item => item[chave])), nome => new Option(nome,nome)));
}
function selecao() {
  return origem.itens.filter(item => item.grupo === campo('grupo').value && item.noite === campo('noite').value);
}
function atualizarValor() {
  const item = selecao().find(item => item.quarto === campo('quarto').value);
  campo('valor').textContent = item ? 'Tarifa regular após flutuação · R$ ' + item.valor : '';
  campo('copiar').disabled = !item;
}
function quartos() { opcoes('quarto',selecao(),'quarto'); atualizarValor(); }
function noites() {
  opcoes('noite',origem.itens.filter(item => item.grupo === campo('grupo').value),'noite');
  quartos();
}
function grupos() {
  const omni = campo('canal').value === 'Omnibees';
  const itens = omni ? origem.itens.filter(item => /^WEB (Café|MAP|PC|FAP)$/.test(item.grupo)) : origem.itens;
  opcoes('grupo',itens,'grupo');
  noites();
  campo('copiar').textContent = omni ? 'Conferir no Calendário 360' : 'Copiar tarifa e abrir a aba do canal';
  status.textContent = itens.length ? '' : 'Exiba WEB Café, WEB MAP, WEB PC ou Todos os grupos no RMS e reabra a extensão.';
}
async function iniciar() {
  const [aba] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!aba?.url?.startsWith('https://portalsueds.com.br/')) throw Error('Abra a extensão na aba do Painel RMS Simples.');
  const frames = await chrome.scripting.executeScript({target:{tabId:aba.id,allFrames:true},func:lerPainel});
  const paineis = frames.map(frame => frame.result).filter(Boolean);
  if (paineis.length !== 1 || !paineis[0].itens.length) throw Error('Selecione o hotel e um grupo com tarifas no RMS Simples e reabra a extensão.');
  origem = paineis[0];
  if(origem.teste){campo('canal').value='Omnibees';campo('canal').disabled=true;}
  campo('hotel').textContent = origem.hotel;
  grupos();
  document.querySelector('form').hidden = false;
}
campo('grupo').onchange = noites;
campo('canal').onchange = grupos;
campo('noite').onchange = quartos;
campo('quarto').onchange = atualizarValor;
campo('copiar').onclick = async () => {
  try {
    const canal = campo('canal').value;
    const abas = await chrome.tabs.query({currentWindow:true,url:'https://' + destinos[canal] + '/*'});
    if (abas.length !== 1) throw Error('Mantenha uma aba de ' + canal + ' aberta nesta janela para conferir o tarifário.');
    const item = selecao().find(item => item.quarto === campo('quarto').value);
    if (canal === 'Omnibees') {
      const multipax=origem.hotel==='Sueds Plaza' && item.grupo==='WEB Café' && item.quarto==='STD';
      if(multipax && !origem.stdPax)throw Error('Escolha a noite no teste do painel e confira a grade STD de 1 a 4 adultos.');
      const pedido = {...item,hotel:origem.hotel,alvos:multipax?origem.stdPax:[Math.round(Number(item.valor.replaceAll('.','').replace(',','.'))*100)],multipax};
      const consultar = async (aplicar, anterior) => {
        const [execucao] = await chrome.scripting.executeScript({target:{tabId:abas[0].id},func:calendario360,args:[pedido,aplicar,anterior]});
        if (!execucao?.result || execucao.result.erro) throw Error(execucao?.result?.erro || 'Calendário indisponível.');
        return execucao.result;
      };
      campo('copiar').disabled = true;
      const {atual} = await consultar(false,null);
      if (atual.every((c,i)=>c===pedido.alvos[i])) {
        status.textContent = 'A tarifa do Calendário 360 já está igual ao RMS.';
        return;
      }
      if (confirm([pedido.hotel, pedido.noite, pedido.grupo, pedido.quarto,...atual.map((c,i)=>(multipax?i+1:2)+' Pax: '+(c/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})+' → '+(pedido.alvos[i]/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})), 'Salvar no Calendário 360?'].join('\n'))) {
        const resultado = await consultar(true,atual);
        status.textContent = resultado.mensagem;
        await chrome.tabs.update(abas[0].id,{active:true});
      }
      return;
    }
    await navigator.clipboard.writeText(item.valor.replaceAll('.',''));
    await chrome.tabs.update(abas[0].id,{active:true});
  } catch (erro) { status.textContent = erro.message; }
  finally { atualizarValor(); }
};
iniciar().catch(erro => {status.textContent = erro.message;});
