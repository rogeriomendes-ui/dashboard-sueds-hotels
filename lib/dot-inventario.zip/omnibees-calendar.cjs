// Read only the displayed Calendar 360 cells. Never click a sales-status cell
// or the calendar's Save command.
function extractDOM() {
  const lines=[...document.querySelectorAll('ob-excel-table-line')];
  return {
    hotel:document.querySelector('.context-sub-information')?.textContent.trim(),
    period:document.querySelector('#tdt-excel-from-date')?.value,
    lines:lines.map(e=>({
      id:e.id,group:e.classList.contains('group'),expanded:e.classList.contains('expanded'),active:!e.querySelector('.excel-left-cell .status-inactive'),
      name:e.querySelector('.excel-left-cell [data-cy^="table-table_line-line_name_-"]')?.textContent.trim(),
      cells:[...e.querySelectorAll(':scope > .excel-right-cells > .excel-cell')].map(c=>({
        cy:c.getAttribute('data-cy'),text:c.textContent.trim(),
        ...(c.getAttribute('data-cy')?.endsWith('_Mínimo de Dias') ? {minimumInput:c.querySelector('input')?.value} : {}),
        inputClass:c.querySelector('.excel-input')?.className,
        statusClass:c.querySelector('.status')?.className
      }))
    }))
  };
}
const key=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
const TRANCOSO_ROOMS=['Suite Deluxe','Suite Deluxe Quádrupla','Suite Junior','Suite Standard'];
function excludedFromSale(hotelId,room){return String(hotelId)==='19865'&&!TRANCOSO_ROOMS.some(r=>key(r)===key(room));}
function normalize(raw,hotelId,period,rooms) {
  const {HOTELS}=require('./omnibees.cjs'),{dates,excluded}=require('./omnibees-inventory.cjs');
  if(key(raw.hotel)!==key(HOTELS[hotelId]))throw new Error('Hotel do Calendário 360 divergente.');
  const {br}=require('./common.cjs');
  if(raw.period!==`${br(period.from)} — ${br(period.to)}`)throw new Error('Período do Calendário 360 divergente.');
  const expected=dates(period.from,period.to),groups=new Map();let room;
  for(const line of raw.lines||[]) {
    if(line.group) {
      room=line.name;
      if(!room||groups.has(key(room)))throw new Error('Categoria duplicada/ausente no Calendário 360.');
      if(!line.cells.every(c=>c.cy?.includes('_Inventário Disponível')))throw new Error('Calendário 360 não está na Vista Quarto.');
      groups.set(key(room),{name:room,inventory:line.cells,rates:[]});
    } else if(room&&line.cells.some(c=>c.cy?.includes('_Fechar/Abrir Vendas'))) {
      if(!line.name)throw new Error('Tarifário sem nome no Calendário 360.');
      groups.get(key(room)).rates.push({...line});
    } else if(room && line.cells.some(c=>c.cy?.endsWith('_Mínimo de Dias'))) {
      const rate=groups.get(key(room)).rates.at(-1);
      if(rate) rate.minimumCells=line.cells;
    }
  }
  const included=[...groups.values()].filter(g=>!excluded(hotelId,g.name)&&!excludedFromSale(hotelId,g.name));
  if(JSON.stringify(included.map(g=>key(g.name)).sort())!==JSON.stringify(rooms.filter(r=>!excludedFromSale(hotelId,r)).map(key).sort()))throw new Error('Categorias do Calendário 360 divergem do inventário.');
  const rows=rooms.filter(r=>excludedFromSale(hotelId,r)).flatMap(room=>expected.map(date=>({room,date,stopSales:false,reference:JSON.stringify({excludedFromSale:true,reason:'Trancoso: somente quatro categorias com WEB ativo, conforme autorização.'})})));
  for(const g of included) {
    const web=g.rates.filter(r=>r.active!==false&&/\bWEB\b/.test(key(r.name)));
    if(!web.length)throw new Error(`Tarifário WEB ausente em ${g.name}.`);
    for(const date of expected) {
      const inventory=g.inventory.filter(c=>c.cy===`table-table_line-status_line_cell_-_${date}_Inventário Disponível`);
      if(inventory.length!==1||!/^excel-input\b/.test(inventory[0].inputClass||'')||! /\b(opened|closed|unavailable)\b/.test(inventory[0].inputClass))throw new Error('Data incompleta no Calendário 360.');
      const states=web.map(r=>{
        const cells=r.cells.filter(c=>c.cy===`table-table_line-sales_status_line_cell_-_${date}_Fechar/Abrir Vendas`);
        if(cells.length!==1||!/^status (open|closed)$/.test(cells[0].statusClass||''))throw new Error('Estado WEB ausente ou desconhecido no Calendário 360.');
        const minimum=r.minimumCells?.filter(c=>c.cy===`table-table_line-restriction_line_cell_-_${date}_Mínimo de Dias`);
        const value=minimum?.length===1 ? minimum[0].minimumInput : null;
        return {rate:r.name,closed:cells[0].statusClass==='status closed',minimumStay:/^\d+$/.test(value)?Number(value):null};
      });
      const inventoryClosed=/\bclosed\b/.test(inventory[0].inputClass);
      rows.push({room:rooms.find(r=>key(r)===key(g.name)),date,stopSales:inventoryClosed||states.every(s=>s.closed),reference:JSON.stringify({inventoryClosed,web:states})});
    }
  }
  return rows;
}
async function query(page,period) {
  const {selectCalendarDate}=require('./omnibees-inventory.cjs');
  const {br}=require('./common.cjs');
  const selected=`${br(period.from)} — ${br(period.to)}`,count=require('./omnibees-inventory.cjs').dates(period.from,period.to).length;
  if(await page.locator('#tdt-excel-from-date').inputValue()===selected){
    const complete=await page.locator('ob-excel-table-line.group').evaluateAll((es,count)=>es.length>0&&es.every(e=>e.querySelectorAll(':scope > .excel-right-cells > .excel-cell').length>=count),count);
    if(complete)return;
    // Reapplying an unchanged range sends no request. Refresh first when old
    // virtualized columns remain, then restore the requested range if reset.
    const waiting=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/RateCalendarExcel/ListRateCalendarExcel'),{timeout:90000});
    await page.locator('[data-cy="refresh_btn-input"]').click();
    const response=await waiting;if(!response.ok())throw new Error('Atualização do Calendário 360 retornou erro.');await response.finished();
    await page.waitForTimeout(300);
    if(await page.locator('#tdt-excel-from-date').inputValue()===selected)return;
  }
  const calendar=page.locator('.calendar-wrapper');
  for(let attempt=0;attempt<2&&!await calendar.isVisible();attempt++){
    await page.locator('#tdt-excel-from-date + button').click();
    try{await calendar.waitFor({state:'visible',timeout:5000});}catch(e){if(attempt===1)throw e;}
  }
  await selectCalendarDate(page,period.from);await selectCalendarDate(page,period.to);
  const waiting=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/RateCalendarExcel/ListRateCalendarExcel'),{timeout:90000});
  await page.getByRole('button',{name:'Definir Período',exact:true}).click();
  const response=await waiting;if(!response.ok())throw new Error('Consulta Calendário 360 retornou erro.');await response.finished();
}
async function capture(page,hotelId,chunks,dir,progress=()=>{}) {
  const {dates}=require('./omnibees-inventory.cjs'),{saveJson}=require('./common.cjs'),path=require('node:path');
  const menu=page.getByText('Tarifários e Disponibilidade',{exact:true}).first(),item=page.locator('[data-cy="navigation_menu-label_-_Calendário 360"]');
  if(!await page.getByText('Vista Quarto',{exact:true}).isVisible()){
    if(!await item.isVisible())await menu.click();
    const loading=page.waitForResponse(r=>new URL(r.url()).pathname.endsWith('/RateCalendarExcel/ListRateCalendarExcel'),{timeout:90000});
    await item.click();const response=await loading;
    if(!response.ok())throw new Error('Abertura do Calendário 360 retornou erro.');await response.finished();
  }
  await page.getByText('Vista Quarto',{exact:true}).waitFor({state:'visible',timeout:30000});
  await page.locator('ob-excel-table-line .excel-cell').first().waitFor({state:'attached',timeout:60000});
  await page.setViewportSize({width:3600,height:900});
  const rooms=chunks[0].roomTypes,days=dates(chunks[0].period.from,chunks.at(-1).period.to),rows=[];
  // The calendar virtualizes columns. A wide viewport exposes every day of each 30-day window.
  for(let i=0;i<days.length;i+=30) {
    const period={from:days[i],to:days[Math.min(i+29,days.length-1)]};
    const file=path.join(dir,`calendar-${hotelId}-${period.from}.json`);
    if(require('node:fs').existsSync(file)){
      const raw=JSON.parse(require('node:fs').readFileSync(file,'utf8'));
      if(!Number.isFinite(Date.parse(raw.capturedAt)))throw new Error('Horário de Stop Sales ausente na retomada.');
      rows.push(...normalize(raw,hotelId,period,rooms).map(r=>({...r,salesCapturedAt:raw.capturedAt})));continue;
    }
    progress({step:'stop-sales',hotel:chunks[0].hotel,period,message:`Consultando Stop Sales WEB · ${chunks[0].hotel} · ${period.from} a ${period.to}`});
    await page.setViewportSize({width:3600,height:900});
    let stage='consulta do período';
    for(let retry=0;retry<2;retry++) {
    try {
    await query(page,period);
    await page.getByText('Vista Quarto',{exact:true}).click();
    await page.waitForFunction(()=>{const e=document.querySelector('ob-excel-table-line.group');return e?.querySelector('[data-cy$="_Inventário Disponível"]');},null,{timeout:30000});
    // The .expanded class stays stale after toggling. Inspect actual child rows
    // and open each room at most once; never loop on that CSS class.
    const groupIds=await page.locator('ob-excel-table-line.group').evaluateAll(es=>es.map(e=>({id:e.id,name:e.querySelector('.groupName')?.textContent.trim()})));
    for(const {id,name} of groupIds){
      if(excludedFromSale(hotelId,name))continue;
      stage=`carregamento dos dias de ${name}`;
      await page.locator(`#${id}`).scrollIntoViewIfNeeded();
      await page.waitForFunction(({id,count})=>document.getElementById(id)?.querySelectorAll(':scope > .excel-right-cells > .excel-cell').length>=count,{id,count:dates(period.from,period.to).length},{timeout:10000});
      const hasChildren=await page.evaluate(id=>{const es=[...document.querySelectorAll('ob-excel-table-line')],i=es.findIndex(e=>e.id===id);return i>=0&&es[i+1]&&!es[i+1].classList.contains('group');},id);
      if(hasChildren)continue;
      stage=`expansão dos tarifários de ${name}`;
      await page.locator(`#${id} [data-cy="table-table_line-group_expand_collapse_btn"]`).click();
      await page.waitForFunction(id=>{const es=[...document.querySelectorAll('ob-excel-table-line')],i=es.findIndex(e=>e.id===id);return i>=0&&es[i+1]&&!es[i+1].classList.contains('group');},id,{timeout:10000});
    }
    const webIds=await page.locator('ob-excel-table-line:not(.group)').evaluateAll(lines=>lines.filter(line=>{
      const label=line.querySelector('.excel-left-cell [data-cy^="table-table_line-line_name_-"]');
      return /\bWEB\b/i.test(label?.textContent||'') && !line.querySelector('.excel-left-cell .status-inactive') &&
        line.querySelector('[data-cy$="_Fechar/Abrir Vendas"]');
    }).map(line=>line.id));
    for(const id of webIds){
      const row=page.locator('#'+id);
      const expanded=await row.evaluate(e=>Boolean(e.nextElementSibling?.querySelector('[data-cy*="price_line_cell_"], [data-cy*="restriction_line_cell_"]')));
      if(!expanded)await row.locator('[data-cy="table-table_line-group_expand_collapse_btn"]').click();
    }
    break;
    } catch(error) {
      if(error.name!=='TimeoutError')throw error;
      if(retry===1)throw new Error(`Calendário 360 de ${chunks[0].hotel}, ${period.from} a ${period.to}: tempo esgotado em ${stage}, mesmo após nova consulta. Base anterior preservada.`,{cause:error});
      progress({step:'stop-sales',hotel:chunks[0].hotel,period,message:`Repetindo consulta do Calendário 360 após demora em ${stage}.`});
      stage='consulta do período';
    }
    }
    let previous='',stable=0,result,raw,lastError;
    for(let attempt=0;attempt<60;attempt++) {
      raw=await page.evaluate(extractDOM);
      try{result=normalize(raw,hotelId,period,rooms);const digest=JSON.stringify(raw);stable=digest===previous?stable+1:0;previous=digest;if(stable>=2)break;}catch(e){lastError=e;stable=0;}
      await page.waitForTimeout(300);
    }
    if(stable<2)throw new Error(`Calendário 360 incompleto: ${lastError?.message||'carregamento pendente'}`);
    const capturedAt=new Date().toISOString();
    saveJson(file,{...raw,capturedAt});
    rows.push(...result.map(r=>({...r,salesCapturedAt:capturedAt})));
  }
  const lookup=new Map(rows.map(r=>[JSON.stringify([r.room,r.date]),r]));
  for(const chunk of chunks){
    for(const r of chunk.rows){const status=lookup.get(JSON.stringify([r.room,r.date]));if(!status)throw new Error('Stop Sales parcial; base anterior preservada.');Object.assign(r,status,{sellable:excludedFromSale(hotelId,r.room)||status.stopSales?0:r.available});}
    chunk.calendarVerified=true;
  }
  return chunks;
}
module.exports={extractDOM,normalize,capture,excludedFromSale,TRANCOSO_ROOMS};



