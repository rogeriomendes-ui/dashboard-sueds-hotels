const fs=require('node:fs'),path=require('node:path');
const {ROOT,config,localToday,saveJson,runDir}=require('./common.cjs');
const {HOTELS,hotelKey}=require('./juniper.cjs');
const {dates}=require('./omnibees-inventory.cjs');

const URL='https://intranet.azulviagens.com.br/extranet/alojamiento/?alojamiento=1565&idcco=7620&verVigente=1';
const END='2027-12-31';
const MONTHS=['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
function extractDOM(){
  const rooms={}, minimumByCell=new Map();
  for(const row of document.querySelectorAll('.x-grid3-body tr')){
    const label=row.cells[0]?.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
    if(!/^(?:estancia minima|estadia minima|minimum stay|minimo de noches|minimo de diarias)$/i.test(label||''))continue;
    for(const cell of row.querySelectorAll('[id]')){
      const suffix=cell.id.match(/_(\d+_\d{1,2}_\d{1,2}_\d{4})$/)?.[1];
      if(!suffix)continue;
      const value=(cell.querySelector('input')?.value??cell.textContent).trim();
      minimumByCell.set(suffix,minimumByCell.has(suffix)?null:value);
    }
  }
  for(const table of document.querySelectorAll('.x-grid3-body table')){
    const m=table.rows[0]?.cells[0]?.textContent.trim().match(/^\((\d+)\)\s*(.+)$/);
    if(m){if(rooms[m[1]]&&rooms[m[1]]!==m[2])throw new Error('Categoria mudou entre meses.');rooms[m[1]]=m[2];}
  }
  return {hotel:document.querySelector('#nombreAlo')?.value,fields:Object.fromEntries(['mesIni','anyoIni','mesFin','anyoFin'].map(id=>[id,document.getElementById(id)?.value])),
    selectedRooms:[...document.querySelectorAll('#tdHabitaciones input[id^="thaSel_"]')].filter(e=>e.id!=='thaSel_0').map(e=>({id:e.id.replace('thaSel_',''),checked:e.checked})),rooms,
    cells:[...document.querySelectorAll('.x-grid3-body [id^="cd_"]')].map(e=>({id:e.id,value:e.textContent.trim(),minimum:minimumByCell.get(e.id.slice(3))??null,stop:document.getElementById(e.id.replace(/^cd_/,'ss_'))?.textContent.trim()??null}))};
}
// The calendar displays a rule count. Its XML links each room/night to real rule IDs.
async function readMinimums(page, raw, xml, from, to){
  const cells = await page.evaluate(({xml,months,from,to})=>{
    const doc=new DOMParser().parseFromString(xml,'application/xml');
    const results=[],seen=new Set();
    let year,month,room;
    for(const row of doc.querySelectorAll('item')){
      const type=row.getAttribute('tipo');
      if(type==='mes'){
        year=row.querySelector('d1')?.textContent.trim();
        month=months.findIndex(m=>m.toUpperCase()===row.querySelector('d0')?.textContent.trim().toUpperCase())+1;
      }
      if(type==='ha')room=row.querySelector('d0')?.getAttribute('idtha');
      if(type!=='rs')continue;
      if(!month||!/^\d{4}$/.test(year)||!/^\d+$/.test(room))throw Error('Período/categoria de restrição Azul inválido.');
      for(const day of row.children){
        const d=Number(day.tagName.slice(1));if(!d)continue;
        const date=year+'-'+String(month).padStart(2,'0')+'-'+String(d).padStart(2,'0');
        if(date<from||date>to)continue;
        const suffix=[room,d,month,year].join('_'),cell=document.getElementById('rs_'+suffix);
        const text=day.textContent.trim(),ids=text.match(/\d+/g)||[];
        seen.add(suffix);
        if(!ids.length)continue;
        if(!cell||Number(cell.textContent.trim())!==ids.length)throw Error('Quantidade de regras Azul divergente: '+suffix);
        results.push({suffix,ids});
      }
    }
    if(!doc.querySelector('item[tipo="rs"]'))throw Error('Grade de restrições Azul ausente.');
    for(const cell of document.querySelectorAll('.x-grid3-body [id^="cd_"]')){
      const [,room,d,m,y]=cell.id.split('_');
      const date=y+'-'+m.padStart(2,'0')+'-'+d.padStart(2,'0');
      if(date>=from&&date<=to&&Number(d)<=new Date(Date.UTC(Number(y),Number(m),0)).getUTCDate()&&!seen.has([room,d,m,y].join('_')))throw Error('Grade de restrições Azul incompleta: '+cell.id);
    }
    return results;
  },{xml,months:MONTHS,from,to});
  const rules=new Map(),byCell=new Map(raw.cells.map(c=>[c.id.slice(3),c]));
  for(const {suffix,ids} of cells){
    if(ids.some(id=>!rules.has(id))){
      const detail=page.waitForResponse(r=>r.ok()&&new globalThis.URL(r.url()).pathname.endsWith('/handlers/funcionesGenerales.aspx')&&new URLSearchParams(r.request().postData()).get('id')?.match(/\d+/g)?.some(id=>ids.includes(id)),{timeout:30000});
      const [response]=await Promise.all([detail,page.locator('#rs_'+suffix).dblclick()]);
      const records=await page.evaluate(xml=>[...new DOMParser().parseFromString(xml,'application/xml').querySelectorAll('reg')].map(reg=>{
        const field=name=>reg.querySelector(name)?.textContent.trim();
        return {id:field('id'),active:field('activo'),value:field('valorEstMin'),label:field('seleccionado')};
      }),await response.text());
      for(const r of records){
        if(!ids.includes(r.id))continue;
        if(!/^(true|false)$/i.test(r.active)||(/estancia m[ií]nima/i.test(r.label)&&!/^\d+$/.test(r.value)))throw Error('Mínimo Azul inválido: '+r.id);
        rules.set(r.id,/^true$/i.test(r.active)&&/^\d+$/.test(r.value)?Number(r.value):null);
      }
      if(ids.some(id=>!rules.has(id)))throw Error('Detalhe de restrição Azul incompleto: '+suffix);
      await page.locator('.x-window:visible .x-tool-close').last().click();
    }
    const values=[...new Set(ids.map(id=>rules.get(id)).filter(n=>n!=null))];
    if(values.length>1)throw Error('Múltiplos mínimos Azul para a mesma categoria e data: '+suffix);
    if(values.length)byCell.get(suffix).minimum=String(values[0]);
  }
}
function normalize(raw,hotel,from,to=END,capturedAt=new Date().toISOString()){
  if(!HOTELS.includes(hotel)||hotelKey(raw.hotel)!==hotel)throw new Error('Hotel Azul selecionado diverge da consulta.');
  const expectedFields={mesIni:MONTHS[Number(from.slice(5,7))-1],anyoIni:from.slice(0,4),mesFin:MONTHS[Number(to.slice(5,7))-1],anyoFin:to.slice(0,4)};
  if(Object.keys(expectedFields).some(k=>raw.fields?.[k]!==expectedFields[k]))throw new Error('Período Azul diverge do solicitado.');
  const expected=dates(from,to),wanted=new Set(expected),roomIds=Object.keys(raw.rooms||{}).sort(),seen=new Set(),rows=[];
  if(!roomIds.length||!raw.selectedRooms?.length||raw.selectedRooms.some(r=>!r.checked)||JSON.stringify(raw.selectedRooms.map(r=>r.id).sort())!==JSON.stringify(roomIds))throw new Error('Categorias Azul não estão completas/selecionadas.');
  for(const c of raw.cells||[]){
    const m=c.id.match(/^cd_(\d+)_(\d{1,2})_(\d{1,2})_(\d{4})$/);if(!m)throw new Error('Identificador de data Azul mudou.');
    const [,roomId,dd,mm,yyyy]=m,date=`${yyyy}-${mm.padStart(2,'0')}-${dd.padStart(2,'0')}`,dt=new Date(date+'T12:00:00Z');
    if(!Number.isFinite(dt.getTime())||dt.toISOString().slice(0,10)!==date){if(c.value||c.stop)throw new Error('Célula Azul preenchida em data inexistente.');continue;}
    if(!wanted.has(date))continue;
    if(!roomIds.includes(roomId)||!/^[-+]?\d+$/.test(c.value)||!Number.isSafeInteger(Number(c.value))||c.stop===null)throw new Error('Quantidade ou Stop Sales Azul ausente/inválido.');
    const k=JSON.stringify([roomId,date]);if(seen.has(k))throw new Error('Categoria/data Azul duplicada.');seen.add(k);
    const available=Number(c.value),stopSales=/\bSS\b/i.test(c.stop);
    rows.push({hotel,roomId,room:raw.rooms[roomId],date,minimumStay:/^\d+$/.test(c.minimum)&&Number.isSafeInteger(Number(c.minimum))?Number(c.minimum):null,available,stopSales,stopText:c.stop,sellable:stopSales?0:Math.max(0,available),capturedAt});
  }
  if(rows.length!==expected.length*roomIds.length)throw new Error(`Mapa Azul incompleto: ${hotel}; esperado ${expected.length} dias por categoria.`);
  return {hotel,from,to,capturedAt,roomIds,rows};
}
function validateComplete(captures,from,to=END){
  const expected=dates(from,to),hotels=new Set(),rows=[];
  for(const c of captures){
    if(!HOTELS.includes(c.hotel)||hotels.has(c.hotel)||c.from!==from||c.to!==to||!c.roomIds?.length)throw new Error('Mapa Azul parcial ou hotel repetido.');hotels.add(c.hotel);
    const keys=new Set();
    for(const r of c.rows){const k=JSON.stringify([r.roomId,r.date]);if(keys.has(k)||r.hotel!==c.hotel||!c.roomIds.includes(r.roomId)||!r.room||!expected.includes(r.date)||!Number.isSafeInteger(r.available)||typeof r.stopSales!=='boolean'||typeof r.stopText!=='string'||r.stopSales!==/\bSS\b/i.test(r.stopText)||r.sellable!==(r.stopSales?0:Math.max(0,r.available)))throw new Error('Linha Azul inválida ou duplicada.');keys.add(k);rows.push(r);}
    if(keys.size!==expected.length*c.roomIds.length)throw new Error('Dias/categorias Azul incompletos.');
  }
  if(hotels.size!==HOTELS.length)throw new Error('Mapa Azul parcial: faltam hotéis.');return rows;
}
async function choose(page,id,text){
  if((await page.locator('#'+id).inputValue()).trim()===text)return;
  await page.locator('#'+id).locator('..').locator('img.x-form-arrow-trigger').click();
  await page.locator('.x-combo-list:visible').getByText(text,{exact:true}).click();
  await page.waitForFunction(({id,text})=>document.getElementById(id)?.value.trim()===text,{id,text},{timeout:30000});
}
async function readHotelRoster(page,dir,{timeout=30000,interval=250,now=Date.now,pause=ms=>page.waitForTimeout(ms)}={}){
  const expected=[...HOTELS].sort(),started=now(),observations=[];
  let received=[],normalized=[],matches=0,verified=false;
  try{
    while(now()-started<timeout){
      received=await page.locator('.x-combo-list:visible .x-combo-list-item').allTextContents();
      normalized=received.map(hotelKey).sort();
      const signature=JSON.stringify(normalized);
      if(!observations.length||observations.at(-1).signature!==signature)observations.push({elapsedMs:now()-started,received:[...received],normalized:[...normalized],signature});
      matches=signature===JSON.stringify(expected)?matches+1:0;
      if(matches>=3){verified=true;return normalized;}
      await pause(interval);
    }
    throw new Error(received.length?'Lista dos quatro hotéis Azul mudou. Confira hotel-roster.json.':'A lista de hotéis Azul não concluiu o carregamento. Confira hotel-roster.json.');
  }finally{
    saveJson(path.join(dir,'hotel-roster.json'),{capturedAt:new Date().toISOString(),expected,received,normalized,verified,elapsedMs:now()-started,
      observations:observations.map(({signature,...item})=>item)});
  }
}
async function capture(context,dir,from=localToday(),to=END,progress=()=>{}){
  dates(from,to);const page=context.pages()[0]||await context.newPage(),captures=[];
  await page.goto(URL,{waitUntil:'domcontentloaded',timeout:60000});
  try{await page.locator('#nombreAlo').waitFor({state:'visible',timeout:15000});}catch{
    progress({step:'login',message:'Entre na intranet Azul na janela do programa e mantenha-a aberta. A captura continuará automaticamente.'});
    await page.getByRole('button',{name:'Alojamiento',exact:true}).waitFor({state:'visible',timeout:600000});await page.goto(URL,{waitUntil:'domcontentloaded',timeout:60000});await page.locator('#nombreAlo').waitFor({state:'visible',timeout:30000});
  }
  
  await page.locator('#nombreAlo').locator('..').locator('img.x-form-arrow-trigger').click();
  await readHotelRoster(page,dir);await page.locator('#nombreAlo').press('Escape');
  for(const hotel of HOTELS){
    progress({message:'',hotel,completed:captures.length,total:HOTELS.length,period:{from,to}});
    const label={ 'SUEDS CABRALIA':'Sueds Cabrália','SUEDS PLAZA':'Sueds Plaza','SUEDS PREMIUM':'Sueds Premium','SUEDS SEGUNDO SOL':'Sueds Segundo Sol' }[hotel];
    const previousHotel=(await page.locator('#nombreAlo').inputValue()).trim();
    await choose(page,'nombreAlo',label);
    if(previousHotel!==label)await page.waitForFunction(()=>!document.querySelector('.x-grid3-body table'),null,{timeout:30000});
    await page.waitForFunction(()=>document.querySelector('#tdHabitaciones input[id^="thaSel_"]:not([id="thaSel_0"])')&&![...document.querySelectorAll('.x-mask-msg,.ext-el-mask')].some(e=>e.offsetWidth||e.offsetHeight),null,{timeout:30000});
    for(const [id,text]of Object.entries({mesIni:MONTHS[Number(from.slice(5,7))-1],anyoIni:from.slice(0,4),mesFin:MONTHS[Number(to.slice(5,7))-1],anyoFin:to.slice(0,4)}))await choose(page,id,text);
    const oldGrid=await page.locator('.x-grid3-body table').count()?await page.locator('.x-grid3-body table').first().elementHandle():null;
    const [calendarResponse]=await Promise.all([page.waitForResponse(r=>r.ok()&&new globalThis.URL(r.url()).pathname.endsWith('/handlers/xmlRequest_Calendario.ashx'),{timeout:120000}),page.getByRole('button',{name:'Buscar',exact:true}).click()]);
    if(oldGrid){await page.waitForFunction(e=>!e.isConnected,oldGrid,{timeout:30000});await oldGrid.dispose();}
    await page.waitForFunction(({to})=>{
      const ids=[...document.querySelectorAll('#tdHabitaciones input[id^="thaSel_"]')].filter(e=>e.id!=='thaSel_0').map(e=>e.id.replace('thaSel_',''));
      return ids.length&&ids.every(id=>document.getElementById(`cd_${id}_${Number(to.slice(8))}_${Number(to.slice(5,7))}_${to.slice(0,4)}`))&&![...document.querySelectorAll('.x-mask-msg,.ext-el-mask')].some(e=>e.offsetWidth||e.offsetHeight);
    },{to},{timeout:120000});
    const raw=await page.evaluate(extractDOM);await readMinimums(page,raw,await calendarResponse.text(),from,to);saveJson(path.join(dir,hotel.replace(/ /g,'-')+'-raw.json'),raw);
    const chunk=normalize(raw,hotel,from,to);saveJson(path.join(dir,hotel.replace(/ /g,'-')+'.json'),chunk);captures.push(chunk);
    progress({hotel,completed:captures.length,total:HOTELS.length,period:{from,to}});
  }
  validateComplete(captures,from,to);return captures;
}
module.exports={capture,END};