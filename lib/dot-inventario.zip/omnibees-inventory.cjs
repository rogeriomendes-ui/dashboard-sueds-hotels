const fs = require('node:fs');
const path = require('node:path');
const { ROOT, config, localToday, br, runDir, saveJson } = require('./common.cjs');
const { HOTELS } = require('./omnibees.cjs');
const END = '2027-07-31';
const DAY = 86400000;
function day(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Data do inventário inválida.');
  const result = Date.parse(`${value}T12:00:00Z`);
  if (!Number.isFinite(result) || new Date(result).toISOString().slice(0,10) !== value) throw new Error('Data do inventário inexistente.');
  return result;
}
const iso = value => new Date(value).toISOString().slice(0,10);
function dates(from,to) {
  const first=day(from),last=day(to); if(first>last)throw new Error('Período de inventário invertido.');
  const result=[];for(let d=first;d<=last;d+=DAY)result.push(iso(d));return result;
}
function periods(from=localToday(),to=END) {
  const last=day(to),result=[];
  for(let d=day(from);d<=last;d+=30*DAY)result.push({from:iso(d),to:iso(Math.min(d+29*DAY,last))});
  if(!result.length)throw new Error('O prazo do inventário terminou; configure um novo destino antes de capturar.');
  return result;
}
const key = text => String(text).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toUpperCase();
function excluded(hotelId,room) {
  return String(hotelId)==='11640' && ['APARTAMENTO STANDARD SEM AREA DE LAZER','APARTAMENTO STANDER SEM AREA DE LAZER'].includes(key(room));
}
function extractDOM() {
  return {
    hotel:document.querySelector('.context-sub-information')?.textContent.trim(),
    period:document.querySelector('#tdt-excel-from-date')?.value,
    lines:[...document.querySelectorAll('ob-inv-line')].map(e=>({
      label:e.querySelector('.line-label-span')?.textContent.trim(),
      labelCy:e.querySelector('.line-label-span')?.getAttribute('data-cy'),
      cells:[...e.querySelectorAll('.inv-line-body .inv-cell-data')].map(c=>({cy:c.getAttribute('data-cy'),text:c.textContent.trim()}))
    }))
  };
}
function normalize(raw,hotelId,p,capturedAt=new Date().toISOString()) {
  const hotel=HOTELS[String(hotelId)]; if(!hotel || key(raw.hotel)!==key(hotel))throw new Error('Hotel selecionado diverge do inventário solicitado.');
  const expected=dates(p.from,p.to),expectedRange=`${br(p.from)} — ${br(p.to)}`;
  if(raw.period!==expectedRange)throw new Error(`Datas do inventário divergentes em ${hotel}: ${raw.period}; esperado ${expectedRange}.`);
  const rooms=new Map(),totals=new Map();
  for(const line of raw.lines || []) {
    if(!line.cells?.length)continue;
    const head=line.cells[0].cy?.match(/^calendar_table-inv_line_-_(.+)-type_-_(0|8|10)-date_-_(\d{4}-\d{1,2}-\d{1,2})$/);
    const total=line.cells[0].cy?.match(/^calendar_table-inv_line_total_(rooms|occupied|available)-type_-_(12|13|14)-date_-_/);
    if(!head && !total)continue;
    const room=head?.[1],type=head?.[2] || total[1];
    const expectedLabel={0:'Total de Apartamentos',8:'Ocupados',10:'Total de Disponíveis',rooms:'Total de Apartamentos',occupied:'Total de Ocupados',available:'Total de Disponíveis'}[type];
    if(!String(line.labelCy).endsWith(`-line_label_-_${expectedLabel}`))throw new Error('Rótulo da linha de inventário mudou.');
    if(line.cells.length!==expected.length)throw new Error(`Dias incompletos no inventário: ${hotel}, ${room || type}.`);
    const values=line.cells.map((cell,i)=>{
      const m=cell.cy?.match(/-date_-_(\d{4})-(\d{1,2})-(\d{1,2})$/);
      const cellDate=m?`${m[1]}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`:null;
      if(cellDate!==expected[i] || !/^-?\d+$/.test(cell.text))throw new Error('Data ou disponibilidade ausente/não numérica no inventário.');
      const prefix=head?`calendar_table-inv_line_-_${room}-type_-_${type}-date_-_`:`calendar_table-inv_line_total_${type}-type_-_${total[2]}-date_-_`;
      if(!cell.cy.startsWith(prefix))throw new Error('Célula pertence a outra categoria ou linha.');
      const value=Number(cell.text);if(!Number.isSafeInteger(value))throw new Error('Quantidade de inventário inválida.');return value;
    });
    const group=head?(rooms.get(room)||{}):null;
    if(head) {if(group[type])throw new Error('Categoria/linha duplicada no inventário.');group[type]=values;rooms.set(room,group);}
    else {if(totals.has(type))throw new Error('Total da propriedade duplicado.');totals.set(type,values);}
  }
  if(!rooms.size || !['rooms','occupied','available'].every(t=>totals.has(t)))throw new Error('Inventário sem categorias ou totais completos.');
  for(const [room,r] of rooms) {
    if(!['0','8','10'].every(t=>r[t]))throw new Error(`Categoria incompleta: ${room}.`);
    // Omnibees can report negative occupancy; preserve it when the balance closes.
    expected.forEach((date,i)=>{if(r[0][i]<0 || r[0][i]-r[8][i]!==r[10][i])throw new Error(`Disponibilidade diverge de apartamentos menos ocupados: ${hotel}, ${room}, ${date}.`);});
  }
  for(let i=0;i<expected.length;i++)for(const [type,total]of [['0','rooms'],['8','occupied'],['10','available']]) {
    if([...rooms.values()].reduce((n,r)=>n+r[type][i],0)!==totals.get(total)[i])throw new Error(`Soma das categorias diverge do total da propriedade: ${hotel}, ${expected[i]}.`);
  }
  const rows=[],omitted=[];
  for(const [room,r]of rooms) {
    if(excluded(hotelId,room)){omitted.push(room);continue;}
    expected.forEach((date,i)=>rows.push({hotelId:String(hotelId),hotel,room,date,available:r[10][i],apartments:r[0][i],occupied:r[8][i],capturedAt}));
  }
  if(!rows.length)throw new Error('Nenhuma categoria válida no inventário.');
  return {hotelId:String(hotelId),hotel,period:p,capturedAt,roomTypes:[...rooms.keys()].filter(r=>!excluded(hotelId,r)).sort(),excluded:omitted,rows};
}
function validateComplete(captures,from,to=END,requireCalendar=false) {
  const ranges=periods(from,to),seen=new Set(),rows=[],hotelTypes=new Map();
  for(const c of captures) {
    if(!HOTELS[c.hotelId] || !ranges.some(p=>p.from===c.period.from && p.to===c.period.to))throw new Error('Lote não pertence à cobertura de inventário.');
    const chunkKey=JSON.stringify([c.hotelId,c.period.from]);if(seen.has(chunkKey))throw new Error('Lote de inventário duplicado.');seen.add(chunkKey);
    const types=JSON.stringify(c.roomTypes);if(hotelTypes.has(c.hotelId)&&hotelTypes.get(c.hotelId)!==types)throw new Error('Categorias mudaram entre períodos; capture novamente.');hotelTypes.set(c.hotelId,types);
    const expectedDates=dates(c.period.from,c.period.to),keys=new Set();
    if(c.rows.length!==c.roomTypes.length*expectedDates.length)throw new Error('Cobertura de categorias e dias incompleta.');
    for(const r of c.rows){
      if(requireCalendar&&(c.calendarVerified!==true||typeof r.stopSales!=='boolean'||!r.reference||!Number.isFinite(Date.parse(r.salesCapturedAt))||r.sellable!==((require('./omnibees-calendar.cjs').excludedFromSale(r.hotelId,r.room)||r.stopSales)?0:r.available)))throw new Error('Stop Sales do Calendário 360 incompleto.');
      const rowKey=JSON.stringify([r.hotelId,r.room,r.date]);
      if(keys.has(rowKey)||r.hotelId!==c.hotelId||r.hotel!==HOTELS[c.hotelId]||!c.roomTypes.includes(r.room)||!expectedDates.includes(r.date)||excluded(r.hotelId,r.room)||![r.available,r.apartments,r.occupied].every(Number.isSafeInteger)||r.apartments<0||r.apartments-r.occupied!==r.available)throw new Error('Linha de inventário inválida, excluída ou duplicada.');
      keys.add(rowKey);rows.push(r);
    }
  }
  if(seen.size!==Object.keys(HOTELS).length*ranges.length || hotelTypes.size!==Object.keys(HOTELS).length)throw new Error('Inventário parcial: faltam hotéis ou períodos.');
  return rows;
}
async function refresh(page) {
  const waiting=page.waitForRequest(request=>new URL(request.url()).pathname.endsWith('/Inventory/ListInventory'),{timeout:90000});
  // This is the page's read-only refresh, not the yellow bulk-update command.
  await page.locator('[data-cy="page_title-btn_refresh-input"]').click();
  const response=await (await waiting).response();if(!response?.ok())throw new Error('Consulta de inventário Omnibees retornou erro.');
  await response.finished();
}
async function selectCalendarDate(page,date) {
  const monthNames=['JANEIRO','FEVEREIRO','MARCO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'];
  const target=Number(date.slice(0,4))*12+Number(date.slice(5,7))-1;
  for(let attempt=0;attempt<24;attempt++) {
    const headers=await page.locator('.calendar-wrapper .date-header').evaluateAll(es=>es.map(e=>({month:e.querySelector('.month')?.textContent.trim(),year:e.querySelector('.year')?.textContent.trim()})));
    const values=headers.map(h=>Number(h.year)*12+monthNames.indexOf(key(h.month)));
    const index=values.indexOf(target);
    if(index>=0) {
      await page.locator('.calendar-wrapper .date').nth(index).locator(`.calendar .day[data-cy="${Number(date.slice(8))}-month_id_-_${Number(date.slice(5,7))}"]`).click();return;
    }
    if(!values.length || values.some(v=>!Number.isInteger(v)))throw new Error('Cabeçalho do calendário Omnibees mudou.');
    const old=JSON.stringify(headers);
    await page.locator(`.calendar-wrapper [data-cy="${target<values[0]?'btn_previous':'btn_next'}-input"]`).click();
    await page.waitForFunction(previous=>JSON.stringify([...document.querySelectorAll('.calendar-wrapper .date-header')].map(e=>({month:e.querySelector('.month')?.textContent.trim(),year:e.querySelector('.year')?.textContent.trim()})))!==previous,old,{timeout:10000});
  }
  throw new Error('Calendário não chegou ao mês solicitado.');
}
async function queryPeriod(page,p) {
  await page.locator('#tdt-excel-from-date + button').click();
  await page.locator('.calendar-wrapper').waitFor({state:'visible',timeout:10000});
  await selectCalendarDate(page,p.from);await selectCalendarDate(page,p.to);
  const waiting=page.waitForRequest(request=>new URL(request.url()).pathname.endsWith('/Inventory/ListInventory'),{timeout:90000});
  await page.getByRole('button',{name:'Definir Período',exact:true}).click();
  const response=await (await waiting).response();
  if(!response?.ok())throw new Error('Consulta de disponibilidade retornou erro.');
  await response.finished();
}
async function readStable(page,hotelId,p) {
  const hotel=HOTELS[hotelId],deadline=Date.now()+60000;
  let previous='',stable=0,lastError;
  while(Date.now()<deadline) {
    if(await page.getByText('Seu login expirou.',{exact:true}).isVisible().catch(()=>false))throw new Error('LOGIN_REQUIRED: sessão Omnibees expirou durante o inventário.');
    if(!await page.locator('.context-container.loading').count()) {
      const raw=await page.evaluate(extractDOM);
      try {
        const chunk=normalize(raw,hotelId,p),digest=JSON.stringify(raw);
        if(digest===previous)stable++;else stable=0;
        previous=digest;if(stable>=2)return {raw,chunk};
      }catch(e){lastError=e;stable=0;}
    }
    await page.waitForTimeout(300);
  }
  const error=new Error(`Inventário não concluiu para ${hotel}: ${lastError?.message || 'carregamento pendente'}`);
  if(lastError?.message==='Data ou disponibilidade ausente/não numérica no inventário.')error.code='INVENTORY_MISSING_VALUES';
  throw error;
}
async function readWithRetry(page,hotelId,p,read=readStable,reload=refresh) {
  try {return await read(page,hotelId,p);}
  catch(error) {
    if(error.code!=='INVENTORY_MISSING_VALUES')throw error;
    // Re-query missing cells once; never turn absent inventory into zero.
    await reload(page);
    return read(page,hotelId,p);
  }
}
async function capture(context,cfg,dir,from=localToday(),to=END,progress=()=>{},captures=[]) {
  const page=context.pages()[0] || await context.newPage(),ranges=periods(from,to);
  
  try {
    await page.goto('https://myhotel2.omnibees.com/',{waitUntil:'domcontentloaded',timeout:60000});
    const menu=page.getByText('Tarifários e Disponibilidade',{exact:true}).first();
    try {await menu.waitFor({state:'visible',timeout:15000});}
    catch {
      progress({step:'login',message:'Faça login na janela Omnibees aberta e mantenha-a aberta. A captura do inventário continuará automaticamente.'});
      await menu.waitFor({state:'visible',timeout:600000});
    }
    
    const inventory=page.locator('[data-cy="navigation_menu-label_-_Inventário"]');
    if(!await inventory.isVisible())await menu.click();
    await inventory.click();await page.locator('#tdt-excel-from-date').waitFor({state:'visible',timeout:30000});
    await refresh(page);
    await page.locator('[data-cy="calendar_table-inv_line_total_available-line_label_-_Total de Disponíveis"]').waitFor({state:'attached',timeout:30000});
    await page.locator('.context-sub-information').click();
    await page.locator('.context-menu .item:not(.group)').first().waitFor({state:'visible',timeout:15000});
    const available=await page.locator('.context-menu .item:not(.group)').evaluateAll(es=>es.map(e=>({id:e.querySelector('.item-id')?.textContent.trim(),name:e.querySelector('.label')?.textContent.trim()})));
    if(JSON.stringify(available.map(h=>h.id).sort())!==JSON.stringify(Object.keys(HOTELS).sort()) || available.some(h=>key(h.name)!==key(HOTELS[h.id])))throw new Error('Lista dos cinco hotéis Omnibees mudou; captura bloqueada.');
    await page.locator('.context-sub-information').click();
    for(const [hotelId,hotel]of Object.entries(HOTELS)) {
      const remaining=ranges.filter(p=>!captures.some(c=>c.hotelId===hotelId&&c.period.from===p.from));
      if(!remaining.length&&captures.filter(c=>c.hotelId===hotelId).every(c=>c.calendarVerified))continue;
      if((await page.locator('.context-sub-information').innerText()).trim()!==hotel) {
        await page.locator('.context-sub-information').click();
        await page.locator(`.context-menu .item[data-cy="context_dropdown-item_-_${hotel}"]`).click();
        const confirmation=page.getByRole('heading',{name:'Tem a certeza que pretende mudar de propriedade?',exact:true});
        const confirmVisible=await confirmation.waitFor({state:'visible',timeout:3000}).then(()=>true).catch(()=>false);
        if(confirmVisible)await page.getByRole('button',{name:'Sim',exact:true}).click();
        await page.waitForFunction(name=>document.querySelector('.context-sub-information')?.textContent.trim()===name&&!document.querySelector('.context-container.loading'),hotel,{timeout:60000});
        // Switching property closes the inventory module and returns to Home.
        await page.locator('#tdt-excel-from-date').waitFor({state:'detached',timeout:30000});
        await page.getByText('Meus Favoritos',{exact:true}).waitFor({state:'visible',timeout:30000});
        // Use the sidebar item: the old module's tab also says "Inventário".
        if(!await inventory.isVisible())await menu.click();
        for(let attempt=0;attempt<3;attempt++) {
          await inventory.click();
          const opened=await page.locator('#tdt-excel-from-date').waitFor({state:'visible',timeout:10000}).then(()=>true).catch(()=>false);
          if(opened)break;
          // The property transition can discard the first navigation to a module.
          const atHome=await page.getByText('Meus Favoritos',{exact:true}).isVisible();
          const selected=(await page.locator('.context-sub-information').innerText()).trim();
          if(!atHome || selected!==hotel || attempt===2)throw new Error(`Inventário de ${hotel} não abriu após trocar de propriedade.`);
        }
      }
      for(const p of remaining) {
        progress({hotel,period:p,completed:captures.length,total:ranges.length*Object.keys(HOTELS).length});
        await queryPeriod(page,p);
        const {raw,chunk}=await readWithRetry(page,hotelId,p);
        const file=`inventory-${hotelId}-${p.from}-${p.to}.json`;
        saveJson(path.join(dir,file),{...raw,capturedAt:chunk.capturedAt});
        captures.push({...chunk,file});
        saveJson(path.join(dir,'manifest.json'),captures.map(({rows,...meta})=>({...meta,rows:rows.length})));
      }
      await require('./omnibees-calendar.cjs').capture(page,hotelId,captures.filter(c=>c.hotelId===hotelId),dir,progress);
      saveJson(path.join(dir,'manifest.json'),captures.map(({rows,...meta})=>({...meta,rows:rows.length})));
    }
    validateComplete(captures,from,to,true);
    
    return captures;
  }catch(e){await page.screenshot({path:path.join(dir,'failure.png')}).catch(()=>{});throw e;}
}
module.exports={capture,dates,excluded,selectCalendarDate,END};