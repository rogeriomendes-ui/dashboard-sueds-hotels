const fs=require('node:fs');
const localToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo'}).format(new Date());
const br=date=>date.split('-').reverse().join('/');
const saveJson=(file,value)=>fs.writeFileSync(file,JSON.stringify(value));
module.exports={localToday,br,saveJson};
