const HOTELS=['SUEDS CABRALIA','SUEDS PLAZA','SUEDS PREMIUM','SUEDS SEGUNDO SOL'];
const hotelKey=text=>String(text).normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().replace(/\s+/g,' ').toUpperCase();
module.exports={HOTELS,hotelKey};