const HOTELS = { '2930': 'Sueds Cabralia', '11640': 'Sueds Plaza', '5700': 'Sueds Premium', '10534': 'Sueds Segundo Sol', '19865': 'Sueds Trancoso' };
module.exports={HOTELS};