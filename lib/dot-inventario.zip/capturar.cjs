const fs=require('node:fs/promises'),path=require('node:path'),os=require('node:os');
const {localToday}=require('./common.cjs');
async function capturar(context,source,progress=()=>{}){
  if(!['omnibees','juniper'].includes(source))throw Error('Canal inválido.');
  const collector=require('./'+source+'-inventory.cjs');
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'sueds-inventario-'));
  const page=await context.newPage(), owned={pages:()=>[page]}, from=localToday(),to=collector.END;
  const raw=async name=>JSON.parse(await fs.readFile(path.join(dir,name),'utf8'));
  try{
    const captures=source==='omnibees'?await collector.capture(owned,{},dir,from,to,progress):await collector.capture(owned,dir,from,to,progress);
    const files=[];
    for(const [i,c] of captures.entries()){
      const chunk=source==='omnibees'?{hotelId:c.hotelId,period:c.period,capturedAt:c.capturedAt,inventory:await raw(c.file),calendar:await raw('calendar-'+c.hotelId+'-'+c.period.from+'.json')}:
        {source,hotelId:c.hotel,period:{from,to},capturedAt:c.capturedAt,raw:await raw(c.hotel.replace(/ /g,'-')+'-raw.json')};
      const file=path.join(dir,source+'-'+i+'.json');
      await fs.writeFile(file,JSON.stringify({version:1,chunks:[chunk]}));
      files.push(file);
    }
    return files;
  }finally{await page.close();}
}
async function publicar(context,files){
  const page=await context.newPage();
  try{
    await page.goto('https://portalsueds.com.br/omnibees-inventory-import.html');
    await page.locator('#inventoryForm').waitFor({state:'visible',timeout:120000});
    await page.locator('#inventoryFiles').setInputFiles(files);
    const completed=page.waitForResponse(r=>new URL(r.url()).pathname==='/api/portal/omnibees-inventory-import'&&r.request().postDataJSON()?.action==='complete',{timeout:300000});
    const [response]=await Promise.all([completed,page.locator('#inventorySubmit').click()]);
    const result=await response.json();
    if(!response.ok()||result.status!=='concluido'||result.mode!=='production'||result.result?.verified!==true)throw Error(result.error||'Publicação sem confirmação.');
    return result;
  }finally{await page.close();}
}
module.exports={capturar,publicar};
